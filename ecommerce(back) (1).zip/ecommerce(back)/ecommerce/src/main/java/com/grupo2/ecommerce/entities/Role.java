package com.grupo2.ecommerce.entities;

public enum Role {
    USER,
    ADMIN
}
