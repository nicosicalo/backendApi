package com.grupo2.ecommerce.entities.response;

import com.grupo2.ecommerce.entities.PedidoProducto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PedidoResponse {
    private long id;
    private double precioTotal;
    private int cantidad;
    private long idUsuario;
    private List<ProductoResponse> productos;
}
