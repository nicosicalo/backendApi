package com.grupo2.ecommerce.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private Double precioTotal;
    @Column
    private Integer cantidad;
    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @OneToMany(mappedBy = "pedido")
    private List<PedidoProducto> pedidoProductoList;

    public Pedido(Integer cantidad, Usuario usuario) {
        this.pedidoProductoList = new ArrayList<>();
        this.setPrecioTotal(0.0);
        this.setCantidad(cantidad);
        this.setUsuario(usuario);
    }
    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
        usuario.getPedidos().add(this); // Añade este pedido a la lista de pedidos del usuario
    }
    public void agregarProducto(PedidoProducto pedidoProducto) {
        pedidoProductoList.add(pedidoProducto);
        pedidoProducto.setPedido(this);
        this.precioTotal += pedidoProducto.getProducto().getPrecio();
    }

}
