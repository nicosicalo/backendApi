package com.grupo2.ecommerce.entities.requests;
import lombok.Data;

import java.util.List;

@Data
public class PedidoRequest {
    private long idUsuario;
    private List<Long> productos;


}

