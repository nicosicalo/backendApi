package com.grupo2.ecommerce.repository;


    
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.grupo2.ecommerce.entities.Usuario;
import java.util.List;
import java.util.Optional;


@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    @Query(value = "select U from Usuario U where U.mail = ?1")
    Optional<Usuario> findByMail(String mail);

     boolean existsByMail(String mail);
}

