package com.grupo2.ecommerce.repository;

import com.grupo2.ecommerce.entities.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import com.grupo2.ecommerce.entities.PedidoProducto;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PedidoProductoRepository extends JpaRepository<PedidoProducto, Long> {
    @Query(value = "select p from PedidoProducto p where p.pedido = ?1")
    Optional<PedidoProducto> findById_pedido(Long id_Pedido);
}
