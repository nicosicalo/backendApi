package com.grupo2.ecommerce.controllers;


import com.grupo2.ecommerce.entities.Producto;
import com.grupo2.ecommerce.entities.requests.ProductoRequest;
import com.grupo2.ecommerce.entities.response.ProductoResponse;
import com.grupo2.ecommerce.entities.response.ResponseMessage;
import com.grupo2.ecommerce.exceptions.ProductoDuplicadoException;
import com.grupo2.ecommerce.exceptions.ProductoInexistenteException;
import com.grupo2.ecommerce.service.ProductoService;

import java.io.IOException;
import java.net.URI;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @PutMapping("/editProducto")
    public ResponseEntity<ProductoResponse> editProducto(@RequestBody ProductoRequest productoRequest) {
        try {
            ProductoResponse productoResponse = productoService.editProducto(Long.valueOf(productoRequest.getId()),
                    productoRequest.getNombre(),
                    productoRequest.getDescripcion(),
                    productoRequest.getStock(),
                    productoRequest.getPrecio(),
                    productoRequest.getImage(),
                    productoRequest.getTalle());
            return ResponseEntity.ok(productoResponse);
        } catch (ProductoInexistenteException /*| IOException*/ e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping
    public ResponseEntity<Page<ProductoResponse>> getProductos(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null || size == null) {
            PageRequest pageable = PageRequest.of(0, Integer.MAX_VALUE);
            return ResponseEntity.ok(productoService.getProductos(pageable));
        }
        PageRequest pageable = PageRequest.of(page, size);
        return ResponseEntity.ok(productoService.getProductos(pageable));
    }

    @GetMapping("/{productoId}")
    public ResponseEntity<ProductoResponse> getProductoById(@PathVariable Long productoId) throws ProductoInexistenteException {
        return ResponseEntity.ok(productoService.getProductoById(productoId));
    }

    @GetMapping("/productos/nombre/{nombre}")
    public ResponseEntity<List<ProductoResponse>> getProductoByNombre(@PathVariable String nombre) throws ProductoInexistenteException {
        return ResponseEntity.ok(productoService.getProductoByNombre(nombre));
    }
    @PostMapping("/createProducto")
    public ResponseEntity<ProductoResponse> createProducto(@RequestBody ProductoRequest productoRequest) {
        try {
            Producto producto = productoService.createProducto(productoRequest.getNombre(), productoRequest.getDescripcion(),
                    productoRequest.getStock(), productoRequest.getPrecio(), productoRequest.getImage(),
                    productoRequest.getTalle());
            ProductoResponse productoResponse = new ProductoResponse(producto.getNombre(), producto.getDescripcion(),
                    producto.getPrecio(),producto.getImage(),producto.getStock(), producto.getTalle());
            return ResponseEntity.created(URI.create("/productos/" + producto.getId())).body(productoResponse);
        } catch (ProductoDuplicadoException /*| IOException*/ e){

            return ResponseEntity.badRequest().build();
        }

    }

    @DeleteMapping("/borrarProducto/{nombre}")
    public ResponseEntity<ResponseMessage> deleteProducto(@PathVariable String nombre) {
        try {
            Optional<Producto> resultado = productoService.deleteProducto(nombre);
            if (resultado.isPresent()) {
                return ResponseEntity.ok(new ResponseMessage("El producto ha sido eliminado con éxito"));
            }
            return ResponseEntity.ok(new ResponseMessage("El nombre ingresado no existe"));
        } catch (ProductoInexistenteException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new ResponseMessage("Producto no encontrado"));
        }

    }}