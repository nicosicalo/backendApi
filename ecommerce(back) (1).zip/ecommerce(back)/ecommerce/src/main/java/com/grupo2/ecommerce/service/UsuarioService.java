package com.grupo2.ecommerce.service;


import java.util.Optional;

import com.grupo2.ecommerce.entities.Role;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.exceptions.ContraIncorrectaException;
import com.grupo2.ecommerce.exceptions.MailYaEnUsoException;
import com.grupo2.ecommerce.exceptions.UsuarioDuplicadoException;
import com.grupo2.ecommerce.exceptions.UsuarioNoExisteException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;





public interface UsuarioService {

    public  Page<Usuario> getUsuario(PageRequest pageRequest);
    public  Optional<Usuario> getUsuarioById(Long usuarioId);
    public  Usuario createUsuario(String mail,String contraseña,String nombre,String apellido, Role rol) throws UsuarioDuplicadoException;
    public  Usuario cambiarMail(String mailAct,String NuevoMail) throws  MailYaEnUsoException;
    public  Usuario cambiarContra(String mail,String nuevaContraseña);
} 