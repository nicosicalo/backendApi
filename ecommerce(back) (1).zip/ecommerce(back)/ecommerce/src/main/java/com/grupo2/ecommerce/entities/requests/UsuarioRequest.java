package com.grupo2.ecommerce.entities.requests;

import com.grupo2.ecommerce.entities.Role;
import lombok.Data;

@Data
public class UsuarioRequest {
        private String mail;
        private String contrasenia;
        private String nombre;
        private String apellido;
        private Role role;
}
