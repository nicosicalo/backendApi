package com.grupo2.ecommerce.entities.requests;

import lombok.Data;

import java.util.List;

@Data
public class PedidoProductoRequest {
    private List<Integer> idProductos;

}
