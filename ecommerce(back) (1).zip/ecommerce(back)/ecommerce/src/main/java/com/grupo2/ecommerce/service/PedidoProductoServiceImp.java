package com.grupo2.ecommerce.service;


import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.entities.Producto;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import com.grupo2.ecommerce.repository.PedidoProductoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PedidoProductoServiceImp implements PedidoProductoService {
    @Autowired
    private PedidoProductoRepository pedidoProductoRepository;

    @Override
    public Page<PedidoProducto> getPedidoProductos(PageRequest pageRequest) {
        return this.pedidoProductoRepository.findAll(pageRequest);
    }

    @Override
    public Optional<PedidoProducto> getPedidoProductoById(Long id) {
        return this.pedidoProductoRepository.findById(id);
    }

    @Override
    public PedidoProducto createPedidoProducto(Integer cantidad, Double precio) throws StockInsuficienteException {
        PedidoProducto pedidoProducto = new PedidoProducto();
        Producto producto = pedidoProducto.getProducto();
        if (cantidad <= producto.getStock()) {
            producto.setStock(producto.getStock() - cantidad);
            return this.pedidoProductoRepository.save(pedidoProducto);
        } else {
            throw new StockInsuficienteException();
        }
    }
}
