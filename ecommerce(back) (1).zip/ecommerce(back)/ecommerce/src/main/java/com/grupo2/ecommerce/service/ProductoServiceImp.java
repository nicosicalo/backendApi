package com.grupo2.ecommerce.service;

import com.grupo2.ecommerce.entities.Producto;
import com.grupo2.ecommerce.entities.response.ProductoResponse;
import com.grupo2.ecommerce.exceptions.ProductoDuplicadoException;
import com.grupo2.ecommerce.exceptions.ProductoInexistenteException;
import com.grupo2.ecommerce.repository.ProductoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.ProviderException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductoServiceImp implements ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    @Override
    public ProductoResponse editProducto(Long id, String nombre, String descripcion, Integer stock, Double precio,
                                         String image, String talle) throws ProductoInexistenteException {
        Optional<Producto> producto = this.productoRepository.findByIdAndNotDeleted(id);
        if (producto.isEmpty()) {
            throw new ProductoInexistenteException();
        } else {
            Producto prod = producto.get();
            prod.setNombre(nombre);
            prod.setDescripcion(descripcion);
            prod.setStock(stock);
            prod.setPrecio(precio);
            prod.setImage(image);
            prod.setTalle(talle);
            this.productoRepository.save(prod);
            return new ProductoResponse(prod.getNombre(),
                    prod.getDescripcion(), prod.getPrecio(), prod.getImage(),prod.getStock(), prod.getTalle());
        }
    }

    @Override
    public Page<ProductoResponse> getProductos(PageRequest pageRequest) {
        Page<Producto> productosPage = new PageImpl<>(this.productoRepository.findAllActive());
        List<ProductoResponse> productoResponses = productosPage.getContent().stream()
                .map(p -> new ProductoResponse(p.getNombre(), p.getDescripcion(), p.getPrecio(), p.getImage(),p.getStock(), p.getTalle()))
                .collect(Collectors.toList());
        return new PageImpl<>(productoResponses, pageRequest, productosPage.getTotalElements());
    }

    @Override
    public ProductoResponse getProductoById(Long id_producto) throws ProductoInexistenteException {
        Optional<Producto> producto = this.productoRepository.findByIdAndNotDeleted(id_producto);
        if (producto.isPresent()) {
            return new ProductoResponse(producto.get().getNombre(), producto.get().getDescripcion(),
                    producto.get().getPrecio(), producto.get().getImage(),producto.get().getStock(), producto.get().getTalle());
        }
        throw new ProductoInexistenteException();
    }

    @Override
    public List<ProductoResponse> getProductoByNombre(String nombre) throws ProductoInexistenteException {
        List<Producto> productos = this.productoRepository.findByNombre(nombre);
        if (productos.isEmpty()) {
            throw new ProductoInexistenteException();
        }
        return productos.stream().map(
                p -> new ProductoResponse(p.getNombre(), p.getDescripcion(), p.getPrecio(),
                        p.getImage(),p.getStock(), p.getTalle())
        ).collect(Collectors.toList());
    }

    @Override
    @Transactional(rollbackOn = Throwable.class)
    public Producto createProducto(String nombre, String descripcion, Integer stock, Double precio,
                                   String image, String talle) throws ProductoDuplicadoException {
        List<Producto> productos = this.productoRepository.findAllActive();
        Producto producto = new Producto();
        producto.setNombre(nombre);
        producto.setDescripcion(descripcion);
        producto.setStock(stock);
        producto.setPrecio(precio);
        producto.setImage(image);
        producto.setTalle(talle);
        for (Producto p : productos) {
            if (p.equals(producto)) {
                throw new ProductoDuplicadoException();
            }
        }
        return this.productoRepository.save(producto);
    }

    @Override
    @Transactional
    public Optional<Producto> deleteProducto(String nombre) throws ProductoInexistenteException {
        List<Producto> productos = this.productoRepository.findByNombre(nombre);
        if (productos.isEmpty()) {
            throw new ProductoInexistenteException();
        }
        Producto productoe = productos.get(0);

        Optional<Producto> producto = productoRepository.findByIdAndNotDeleted(productoe.getId());
        if (producto.isEmpty()) {
            throw new ProductoInexistenteException();
        }

        Producto prod = producto.get();
        prod.setDeleted(true);
        this.productoRepository.save(prod);
        return producto;
    }
}