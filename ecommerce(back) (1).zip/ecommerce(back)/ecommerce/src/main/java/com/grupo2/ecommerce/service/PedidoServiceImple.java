package com.grupo2.ecommerce.service;
import com.grupo2.ecommerce.entities.Pedido;
import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.entities.Producto;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.entities.response.PedidoResponse;
import com.grupo2.ecommerce.entities.response.ProductoResponse;
import com.grupo2.ecommerce.exceptions.ProductoInexistenteException;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import com.grupo2.ecommerce.exceptions.UsuarioNoExisteException;
import com.grupo2.ecommerce.repository.PedidoProductoRepository;
import com.grupo2.ecommerce.repository.ProductoRepository;
import com.grupo2.ecommerce.repository.UsuarioRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.grupo2.ecommerce.repository.PedidoRepository;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class PedidoServiceImple implements PedidoService{
    @Autowired
    private PedidoRepository pedidoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private ProductoRepository productoRepository;
    @Autowired
    private PedidoProductoRepository pedidoProductoRepository;
    public Page<Pedido> getPedido(PageRequest pageable){
        return pedidoRepository.findAll(pageable);

    }
    public List<PedidoResponse> GetPedidoByUsuario(String mail) throws UsuarioNoExisteException {
        Optional<Usuario> usuario = usuarioRepository.findByMail(mail);
        if(usuario.isPresent()){
            List<Pedido> pedidos = usuario.get().getPedidos();
            List<PedidoResponse> historial = new ArrayList<PedidoResponse>();
            for (Pedido p : pedidos) {
                historial.add(new PedidoResponse(p.getId(), p.getPrecioTotal(), p.getCantidad(),
                        p.getUsuario().getId(), crearProductoReponse(p)));
            }
            return historial;
        } else {
            throw new UsuarioNoExisteException();
        }
    }


    @Transactional
    public PedidoResponse crearPedido(Long idUsuario, List<Long> productoIds) throws ProductoInexistenteException, StockInsuficienteException {
        verificarPedido(idUsuario, productoIds);

        Optional<Usuario> usuario = usuarioRepository.findById(idUsuario);
        if (usuario.isEmpty()) {
            throw new UsuarioNoExisteException();
        }

        Pedido pedido = new Pedido(productoIds.size(), usuario.get());
        pedido.setPrecioTotal(0.0);

        Set<Long> ids = new HashSet<>(productoIds);

        // Crear un mapa para contar las cantidades de cada producto
        Map<Long, Integer> productCountMap = new HashMap<>();
        for (Long productoId : productoIds) {
            productCountMap.put(productoId, productCountMap.getOrDefault(productoId, 0) + 1);
        }

        // Actualizar el stock y agregar los productos al pedido
        for (Map.Entry<Long, Integer> entry : productCountMap.entrySet()) {
            Long productoId = entry.getKey();
            Integer cantidad = entry.getValue();

            Optional<Producto> producto = productoRepository.findById(productoId);
            if (producto.isEmpty()) {
                throw new ProductoInexistenteException();
            }

            Producto prod = producto.get();
            prod.setStock(prod.getStock() - cantidad);
            pedido = pedidoRepository.save(pedido);
            PedidoProducto pedidoProducto = new PedidoProducto();
            pedidoProducto.setProducto(prod);
            pedidoProducto.setPedido(pedido);

            prod.addPedidoProducto(pedidoProducto);

            pedidoProductoRepository.save(pedidoProducto);
            productoRepository.save(prod);
            pedido.agregarProducto(pedidoProducto);
        }

        // Actualizar el pedido con el precio total calculado
        pedido = pedidoRepository.save(pedido);
        List<ProductoResponse> productoResponses = crearProductoReponse(pedido);

        // Crear y devolver el PedidoResponse
        PedidoResponse pedidoFinal = PedidoResponse.builder()
                .id(pedido.getId())
                .precioTotal(pedido.getPrecioTotal())
                .cantidad(pedido.getCantidad())
                .idUsuario(idUsuario)
                .productos(productoResponses)
                .build();
        return pedidoFinal;
    }

    private List<ProductoResponse> crearProductoReponse(Pedido pedido) {

        return pedido.getPedidoProductoList().stream()
                .map(pp -> ProductoResponse.builder()
                        .nombre(pp.getProducto().getNombre())
                        .descripcion(pp.getProducto().getDescripcion())
                        .precio(pp.getProducto().getPrecio())
                        .talle(pp.getProducto().getTalle())
                        .build())
                .collect(Collectors.toList());
    }

    private void verificarPedido(Long idUsuario, List<Long> productoIds) throws StockInsuficienteException, ProductoInexistenteException {
        Optional<Usuario> usuario = usuarioRepository.findById(idUsuario);
        if (usuario.isEmpty()) {
            throw new UsuarioNoExisteException();
        }

        // Crear un mapa para contar las cantidades de cada producto
        Map<Long, Integer> productCountMap = new HashMap<>();
        for (Long productoId : productoIds) {
            productCountMap.put(productoId, productCountMap.getOrDefault(productoId, 0) + 1);
        }

        // Verificar stock
        for (Map.Entry<Long, Integer> entry : productCountMap.entrySet()) {
            Long productoId = entry.getKey();
            Integer cantidad = entry.getValue();

            Optional<Producto> producto = productoRepository.findById(productoId);
            if (producto.isEmpty()) {
                throw new ProductoInexistenteException();
            }

            Producto prod = producto.get();
            if (cantidad > prod.getStock()) {
                throw new StockInsuficienteException();
            }
        }
}}
