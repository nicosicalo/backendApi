package com.grupo2.ecommerce.exceptions;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "El Pedido que intes")
public class UsuarioNoExisteException extends RuntimeException {
    public UsuarioNoExisteException() {
        super("El usuario que intenta hacer este pedido  no existe");
    }

    public UsuarioNoExisteException(String message) {
        super(message);
    }
}
