package com.grupo2.ecommerce.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "El producto que se esta buscando no existe")
public class ProductoInexistenteException extends Exception{
    public ProductoInexistenteException() {
        super("El producto que se esta buscando no existe");
    }

    public ProductoInexistenteException(String message) {
        super(message);
    }}

