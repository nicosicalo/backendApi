package com.grupo2.ecommerce.service;

import com.grupo2.ecommerce.entities.Pedido;
import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.entities.response.PedidoResponse;
import com.grupo2.ecommerce.entities.response.ProductoResponse;
import com.grupo2.ecommerce.exceptions.PedidoNoExisteException;
import com.grupo2.ecommerce.exceptions.ProductoInexistenteException;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import com.grupo2.ecommerce.exceptions.UsuarioNoExisteException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.Optional;

public interface PedidoService {
    public Page<Pedido> getPedido(PageRequest pageable);
    public List<PedidoResponse> GetPedidoByUsuario(String mail)throws UsuarioNoExisteException;
    public PedidoResponse crearPedido(Long idUsuario, List<Long> productoIds) throws ProductoInexistenteException, StockInsuficienteException;

    //private List<ProductoResponse> crearProductoResponse(Pedido pedido) {return null;}
}
