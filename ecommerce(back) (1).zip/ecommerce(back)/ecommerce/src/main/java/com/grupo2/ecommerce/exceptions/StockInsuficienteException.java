package com.grupo2.ecommerce.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST, reason = "No hay stock para satisfacer la cantidad pedida")
public class StockInsuficienteException extends Exception {
    public StockInsuficienteException() {
        super("No hay stock para satisfacer la cantidad pedida");
    }

    public StockInsuficienteException(String message) {
        super(message);
}}
