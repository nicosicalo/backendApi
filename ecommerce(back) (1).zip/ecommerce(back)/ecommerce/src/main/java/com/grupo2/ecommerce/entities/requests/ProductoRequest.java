package com.grupo2.ecommerce.entities.requests;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;
@Data
public class ProductoRequest {
    private int id;
    private String nombre;
    private String descripcion;
    private int stock;
    private double precio;
    private String image;
    private String talle;
}