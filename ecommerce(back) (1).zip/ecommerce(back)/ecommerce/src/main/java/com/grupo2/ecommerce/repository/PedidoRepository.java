package com.grupo2.ecommerce.repository;

import com.grupo2.ecommerce.entities.Pedido;
import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.entities.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    @Query(value = "select p from Pedido p where p.usuario = ?1")
    List<Pedido> findByid_Usuario(Long id_usuario);
}
