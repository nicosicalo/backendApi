package com.grupo2.ecommerce.controllers;

import com.grupo2.ecommerce.entities.Pedido;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.entities.requests.HistorialRequest;
import com.grupo2.ecommerce.entities.requests.PedidoRequest;
import com.grupo2.ecommerce.entities.requests.UsuarioRequest;
import com.grupo2.ecommerce.entities.response.PedidoResponse;
import com.grupo2.ecommerce.exceptions.ProductoInexistenteException;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import com.grupo2.ecommerce.exceptions.UsuarioDuplicadoException;
import com.grupo2.ecommerce.exceptions.UsuarioNoExisteException;
import com.grupo2.ecommerce.service.PedidoService;
import com.grupo2.ecommerce.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("Pedido")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;
    @GetMapping
    public ResponseEntity<Page<Pedido>> getPedido(@RequestParam(required = false) Integer page,
                                                  @RequestParam(required = false) Integer size){
        if (page == null || size == null)
            return ResponseEntity.ok(pedidoService.getPedido(PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(pedidoService.getPedido(PageRequest.of(page, size)));

    }
    @GetMapping("/historial")
    public ResponseEntity<List<PedidoResponse>> getPedidoByUsuario(@RequestBody HistorialRequest request) throws UsuarioNoExisteException {
        List<PedidoResponse> result = pedidoService.GetPedidoByUsuario(request.getMail());
        return ResponseEntity.ok(result);

    }
    @PostMapping
    public ResponseEntity<PedidoResponse> createPedido(@Valid @RequestBody PedidoRequest pedidoRequest) throws ProductoInexistenteException, StockInsuficienteException {
        PedidoResponse result = pedidoService.crearPedido(pedidoRequest.getIdUsuario(), pedidoRequest.getProductos());
        return ResponseEntity.created(URI.create("/Pedido/" + result.getId())).body(result);
    }




}
