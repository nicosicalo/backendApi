package com.grupo2.ecommerce.entities.requests;

import lombok.Data;

@Data
public class HistorialRequest {
    private String mail;
}
