package com.grupo2.ecommerce.service;
import java.util.List;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.grupo2.ecommerce.entities.Role;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.exceptions.ContraIncorrectaException;
import com.grupo2.ecommerce.exceptions.MailYaEnUsoException;
import com.grupo2.ecommerce.exceptions.UsuarioDuplicadoException;
import com.grupo2.ecommerce.exceptions.UsuarioNoExisteException;
import com.grupo2.ecommerce.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import com.grupo2.ecommerce.controllers.config.JwtService;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.grupo2.ecommerce.controllers.auth.AuthenticationRequest;
import com.grupo2.ecommerce.controllers.auth.AuthenticationResponse;
import com.grupo2.ecommerce.controllers.auth.RegisterRequest;
import com.grupo2.ecommerce.controllers.config.JwtService;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.entities.requests.UsuarioRequest;
import com.grupo2.ecommerce.exceptions.UsuarioDuplicadoException;
import com.grupo2.ecommerce.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Service
public class UsuarioServiceImple implements UsuarioService {
    @Autowired
    private JwtService jwtService;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public Page<Usuario> getUsuario(PageRequest pageable) {
        return usuarioRepository.findAll(pageable);
    }

    public Optional<Usuario> getUsuarioById(Long usuarioId) {
        return usuarioRepository.findById(usuarioId);
    }



    public Usuario createUsuario(String mail, String contraseña, String nombre, String apellido, Role rol) throws UsuarioDuplicadoException {
        Optional<Usuario> usuario= usuarioRepository.findByMail(mail);
        if (usuario.isPresent()) {
            return usuarioRepository.save(new Usuario(mail, contraseña, nombre, apellido, rol));
        }else{
            throw new UsuarioDuplicadoException();
        }

    }
    public Usuario cambiarMail(String mailACt,String mailNuevo) throws MailYaEnUsoException{
        Optional<Usuario> usuario = usuarioRepository.findByMail(mailACt);

            if (usuarioRepository.existsByMail(mailNuevo)) {
                throw new MailYaEnUsoException();
            }else {
            usuario.get().setMail(mailNuevo);
            return usuarioRepository.save(usuario.get());
        }
    }

    public  Usuario cambiarContra(String mail,String nuevaContraseña) {
        Optional<Usuario> usuario = usuarioRepository.findByMail(mail);
        usuario.get().setContrasenia(nuevaContraseña);
        String hashedPassword = passwordEncoder.encode(nuevaContraseña);
        usuario.get().setContrasenia(hashedPassword);
        return usuarioRepository.save(usuario.get());
    }
}


