package com.grupo2.ecommerce.service;


import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;

import java.util.Optional;

public interface PedidoProductoService {
    Page<PedidoProducto> getPedidoProductos(PageRequest pageRequest);

    Optional<PedidoProducto> getPedidoProductoById(Long id);

    PedidoProducto createPedidoProducto(Integer cantidad, Double precio) throws StockInsuficienteException;


}
