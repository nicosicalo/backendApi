package com.grupo2.ecommerce.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Blob;
import java.util.List;

@Data
@NoArgsConstructor
@Entity
public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column
    private String nombre;
    @Column
    private String descripcion;
    @Column
    private Integer stock;
    @Column
    private Double precio;
    @Column
    private String image;
    @Column
    private String talle;
    @Column(nullable = false)
    private boolean isDeleted = false;

    @OneToMany(mappedBy = "producto")
    private List<PedidoProducto> pedidoProductoList;

    public Producto(String nombre, String descripcion, Integer stock, Double precio, String image, String talle) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.stock = stock;
        this.precio = precio;
        this.image = image;
        this.talle = talle;
    }

    public Producto(Long id, String descripcion, Integer stock, Double precio, String image, String talle) {
        this.id = id;
        this.descripcion = descripcion;
        this.stock = stock;
        this.precio = precio;
        this.image = image;
        this.talle = talle;
    }

    public void addPedidoProducto(PedidoProducto pedidoProducto) {
        this.pedidoProductoList.add(pedidoProducto);
    }
}