package com.grupo2.ecommerce.service;


import com.grupo2.ecommerce.controllers.auth.AuthenticationRequest;
import com.grupo2.ecommerce.controllers.auth.AuthenticationResponse;
import com.grupo2.ecommerce.controllers.auth.RegisterRequest;
import com.grupo2.ecommerce.controllers.config.JwtService;
import com.grupo2.ecommerce.entities.Usuario;
import com.grupo2.ecommerce.entities.requests.UsuarioRequest;
import com.grupo2.ecommerce.exceptions.UsuarioDuplicadoException;
import com.grupo2.ecommerce.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthenticationService {
    private final UsuarioRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthenticationResponse register(RegisterRequest request) {

        var usuario = Usuario.builder()
                .nombre(request.getFirstname())
                .apellido(request.getLastname())
                .mail(request.getEmail())
                .contrasenia(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .build();

        Optional<Usuario> usuarioOptional = repository.findByMail(request.getEmail());
        if (usuarioOptional.isEmpty()) {
            repository.save(usuario);
            var jwtToken = jwtService.generateToken(usuario);
            return AuthenticationResponse.builder()
                    .accessToken(jwtToken)
                    .build();
        } else {
            throw new UsuarioDuplicadoException();
        }
    }
    public AuthenticationResponse authenticate(AuthenticationRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(),
                        request.getPassword()));
        var user = repository.findByMail(request.getEmail());
        var jwtToken = jwtService.generateToken(user.get());
        return AuthenticationResponse.builder()
                .accessToken(jwtToken)
                .build();
    }

}
