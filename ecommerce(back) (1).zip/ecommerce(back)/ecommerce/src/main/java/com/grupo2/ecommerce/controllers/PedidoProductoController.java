package com.grupo2.ecommerce.controllers;

import com.grupo2.ecommerce.entities.PedidoProducto;
import com.grupo2.ecommerce.entities.requests.PedidoProductoRequest;
import com.grupo2.ecommerce.exceptions.StockInsuficienteException;
import com.grupo2.ecommerce.service.PedidoProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.Optional;

@RestController
@RequestMapping("PedidoProducto")
public class PedidoProductoController {
    @Autowired
    private PedidoProductoService pedidoProductoService;

    @GetMapping
    public ResponseEntity<Page<PedidoProducto>> getPedidoProducto(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null || size == null) {
            return ResponseEntity.ok(pedidoProductoService.getPedidoProductos(PageRequest.of(0, Integer.MAX_VALUE)));
        }
        return ResponseEntity.ok(pedidoProductoService.getPedidoProductos(PageRequest.of(page, size)));
    }

    @GetMapping("/{pedidoProductoID}")
    public ResponseEntity<PedidoProducto> getPedidoProductoById(@PathVariable Long pedidoProductoID) {
        Optional<PedidoProducto> resultado = pedidoProductoService.getPedidoProductoById(pedidoProductoID);
        return resultado.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.noContent().build());
    }

    //@PostMapping
    /*public ResponseEntity<PedidoProducto> createPedidoProducto(@RequestBody PedidoProductoRequest pedidoProductoRequest) throws StockInsuficienteException {
        PedidoProducto resultado = pedidoProductoService.createPedidoProducto(pedidoProductoRequest.getIdProducto(), pedidoProductoRequest.getIdPedido());
        return ResponseEntity.created(URI.create("/PedidoProducto/" + resultado.getId())).body(resultado);
    }*/
}
