package com.grupo2.ecommerce.entities.requests;

import lombok.Data;

@Data
public class CambiarMailRequest {
    private String mailAct;
    private String mailNuevo;
}
