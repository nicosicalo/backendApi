package com.TpoApi.ecommerce.Excepciones;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
@ResponseStatus(code = HttpStatus.CONFLICT, reason = "La contraseña que ingresaste no coincide con la contraseña del usuario")
public class ContraIncorrectaException extends RuntimeException {
    public ContraIncorrectaException(){
        super("La contraseña que ingresaste no coincide con la contraseña del usuario");
    }

}
