package com.TpoApi.ecommerce.Excepciones;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(code = HttpStatus.BAD_REQUEST, reason = "El usuario que intenta modificar, no existe")
public class UsuarioNoExisteException extends RuntimeException {
    public UsuarioNoExisteException() {
        super("El usuario que intenta modificar, no existe");
    }

    public UsuarioNoExisteException(String message) {
        super(message);
    }
}
