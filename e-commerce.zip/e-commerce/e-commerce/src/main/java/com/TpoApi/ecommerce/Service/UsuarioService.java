package com.TpoApi.ecommerce.Service;


import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;



import com.TpoApi.ecommerce.Entity.Usuario;
import com.TpoApi.ecommerce.Excepciones.ContraIncorrectaException;
import com.TpoApi.ecommerce.Excepciones.MailYaEnUsoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioDuplicadoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioNoExisteException;

public interface UsuarioService {

    public  Page<Usuario> getUsuario(PageRequest pageRequest);
    public  Optional<Usuario> getUsuarioById(Long usuarioId);
    public  Usuario createUsuario(String mail,String contraseña,String nombre,String apellido) throws UsuarioDuplicadoException;
    public  Usuario cambiarMail(String mailAct,String NuevoMail) throws UsuarioNoExisteException,MailYaEnUsoException;
    public  Usuario cambiarContra(String mail,String contraseñaActual,String nuevaContraseña)throws UsuarioNoExisteException,ContraIncorrectaException;
} 