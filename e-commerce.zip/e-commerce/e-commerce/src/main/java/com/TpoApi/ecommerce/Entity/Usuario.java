package com.TpoApi.ecommerce.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
@Entity
public class Usuario {
public Usuario() {
    }

    public Usuario(String mail,String constraseña,String nombre,String apellido) {
        this.mail = mail;
        this.contraseña=contraseña;
        this.nombre = nombre;
        this.apellido= apellido;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column
    @Pattern(regexp = "^[\\w.-]+@gmail\\.com$", message = "El correo electrónico debe ser de Gmail (terminar en '@gmail.com')")

    private String mail;
    @Column
    @Pattern(regexp = ".*\\d.*", message = "La contraseña debe contener al menos un número")
    private String contraseña;

    @Column
    @Pattern(regexp = "^[a-zA-Z]+$", message = "El nombre debe contener solo letras")
    private String nombre;
    
    @Column
    @Pattern(regexp = "^[a-zA-Z]+$", message = "El apellido debe contener solo letras")
    private String apellido;
}
