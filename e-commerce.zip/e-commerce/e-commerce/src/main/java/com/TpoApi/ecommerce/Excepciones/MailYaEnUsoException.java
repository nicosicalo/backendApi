package com.TpoApi.ecommerce.Excepciones;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
@ResponseStatus(code = HttpStatus.CONFLICT, reason = "El nuevo correo ya está en uso")
public class MailYaEnUsoException extends RuntimeException {
    public MailYaEnUsoException() {
        
        super("El nuevo correo ya está en uso");
    }
}

