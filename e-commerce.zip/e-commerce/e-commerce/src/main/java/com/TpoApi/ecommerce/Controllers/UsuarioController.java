package com.TpoApi.ecommerce.Controllers;

import org.springframework.web.bind.annotation.RestController;

import com.TpoApi.ecommerce.Excepciones.ContraIncorrectaException;
import com.TpoApi.ecommerce.Excepciones.MailYaEnUsoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioDuplicadoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioNoExisteException;
import com.TpoApi.ecommerce.Entity.Usuario;
import com.TpoApi.ecommerce.Entity.dto.UsuarioRequest;
import com.TpoApi.ecommerce.Service.UsuarioService;

import jakarta.validation.Valid;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.net.URI;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;






@RestController
@RequestMapping("Usuario")


public class UsuarioController {
    @Autowired
    private UsuarioService UsuarioService;

    @GetMapping
    public ResponseEntity<Page<Usuario>> getUsuario(
            @RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null || size == null)
            return ResponseEntity.ok(UsuarioService.getUsuario(PageRequest.of(0, Integer.MAX_VALUE)));
        return ResponseEntity.ok(UsuarioService.getUsuario(PageRequest.of(page, size)));
    }

    @GetMapping("/{usuarioId}")
    public ResponseEntity<Usuario> getUsuarioById(@PathVariable Long usuarioId) {
        Optional<Usuario> result = UsuarioService.getUsuarioById(usuarioId);
        if (result.isPresent())
            return ResponseEntity.ok(result.get());

        return ResponseEntity.noContent().build();
    }

    @PostMapping
    public ResponseEntity<Usuario> createUsuario(@Valid @RequestBody UsuarioRequest usuarioRequest)
            throws UsuarioDuplicadoException {
        Usuario result = UsuarioService.createUsuario(usuarioRequest.getMail(),usuarioRequest.getContraseña(),usuarioRequest.getNombre(),usuarioRequest.getApellido());
        return ResponseEntity.created(URI.create("/usuario/" + result.getId())).body(result);
    }
    @PutMapping("/{mailAct,mailNuevo}")
    public ResponseEntity<Usuario> CambiarMail(@RequestParam String mailAct, @RequestParam String mailNuevo) throws UsuarioNoExisteException,MailYaEnUsoException {
        Usuario result = UsuarioService.cambiarMail(mailAct, mailNuevo);
        return ResponseEntity.ok(result);
        
    }
    @PutMapping("/{mail,contraActual,contraNueva}")
    public ResponseEntity<Usuario> CambiarContra(@RequestParam String mail, @RequestParam String contraActual,@RequestParam String contraNueva) throws UsuarioNoExisteException,ContraIncorrectaException {
        Usuario result = UsuarioService.cambiarContra(mail, contraActual, contraNueva);
        return ResponseEntity.ok(result);
        
    }
}
    
    


