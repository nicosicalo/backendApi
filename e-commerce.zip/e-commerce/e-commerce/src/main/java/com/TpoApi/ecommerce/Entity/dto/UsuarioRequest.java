package com.TpoApi.ecommerce.Entity.dto;

import lombok.Data;

@Data
public class UsuarioRequest {
    
        private int id;
        private String mail;
        private String contraseña;
        private String nombre;
        private String apellido;
    
}
