package com.TpoApi.ecommerce.Service;
import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.TpoApi.ecommerce.Excepciones.ContraIncorrectaException;
import com.TpoApi.ecommerce.Excepciones.MailYaEnUsoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioDuplicadoException;
import com.TpoApi.ecommerce.Excepciones.UsuarioNoExisteException;
import com.TpoApi.ecommerce.Entity.Usuario;
import com.TpoApi.ecommerce.Repository.UsuarioRepository;

@Service
public class UsuarioServiceImple implements UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public Page<Usuario> getUsuario(PageRequest pageable) {
        return usuarioRepository.findAll(pageable);
    }

    public Optional<Usuario> getUsuarioById(Long usuarioId) {
        return usuarioRepository.findById(usuarioId);
    }

    public Usuario createUsuario(String mail,String contraseña,String nombre,String apellido) throws UsuarioDuplicadoException {
        List<Usuario> usuarios = usuarioRepository.findByMail(mail);
        if (usuarios.isEmpty())
            return usuarioRepository.save(new Usuario(mail,contraseña,nombre,apellido));
        throw new UsuarioDuplicadoException();
    }
    public Usuario cambiarMail(String mailACt,String mailNuevo) throws UsuarioNoExisteException,MailYaEnUsoException{
        List<Usuario> usuarios = usuarioRepository.findByMail(mailACt);
        if(usuarios.isEmpty()){


            throw new UsuarioNoExisteException();

        }else{
            if (usuarioRepository.existsByMail(mailNuevo)) {
                throw new MailYaEnUsoException();
            }
            Usuario usuario = usuarios.get(0);
            usuario.setMail(mailNuevo);
             return usuarioRepository.save(usuario);
        }

    }
    public  Usuario cambiarContra(String mail,String contraseñaActual,String nuevaContraseña) 
    throws UsuarioNoExisteException,ContraIncorrectaException{
        List<Usuario> usuarios = usuarioRepository.findByMail(mail);
        if(usuarios.isEmpty()){
            throw new UsuarioNoExisteException();
        }else{
            Usuario usuario = usuarios.get(0);
            String contra =usuario.getContraseña();
            if(contra.equals(contraseñaActual)    ){
                throw new ContraIncorrectaException();
            }
            usuario.setContraseña(nuevaContraseña);
            return usuarioRepository.save(usuario);
        }
       
        
    }
}

